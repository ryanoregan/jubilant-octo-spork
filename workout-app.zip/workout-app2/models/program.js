import { Workout } from './workout.js'
// import { JSDOM } from 'jsdom'
import { openDB } from 'idb'
// const dom = new JSDOM(`<!DOCTYPE html><html><body></body></html>`, {
//     url: "http://localhost", // Set a URL for the JSDOM environment
//   })
  
//   // Get the window object out of the JSDOM instance
//   const { window } = dom
  
//   // Set up a global localStorage using the window object from jsdom
//   global.localStorage = window.localStorage


export class Program {
    constructor() {
        this.workoutCount = 0
        this.allMyWorkouts = []
        this.originalState = null
        
    }
    

//    2) Add a part

    addWorkout(newDate = new Date(), newType = 'Run', newDuration = 30, newAverageHeartRate = 120) {
         // Validate inputs before creating a new Workout
         if (typeof newDate === 'string') {
            const datePattern = /^\d{4}-\d{2}-\d{2}$/;
            if (!datePattern.test(newDate)) {
                throw new Error('Invalid date format');
            }
        } else if (!(newDate instanceof Date && !isNaN(newDate))) {
            throw new Error('Invalid date');
        }
        if (typeof newType !== 'string') {
            throw new Error('Invalid type')
        }
        if (typeof newDuration !== 'number' || newDuration <= 0) {
            throw new Error('Invalid duration')
        }
        if (typeof newAverageHeartRate !== 'number' || newAverageHeartRate <= 0) {
            throw new Error('Invalid average heart rate')
        }
        const NEW_WORKOUT = new Workout(newDate, newType, newDuration, newAverageHeartRate)
        this.allMyWorkouts.push(NEW_WORKOUT)
        this.workoutCount += 1
    }

//     3) Sort parts

    sortWorkout() {
        this.allMyWorkouts.sort((a, b) => {
            if (a.date < b.date) {
                return -1
            }
            if (a.date > b.date) {
                return 1
            }

            return 0
        })
    }



// 4) Find a part given a search criterion or filter parts

    filterWorkouts(criterion) {
        return this.allMyWorkouts
            .filter(workout => workout.type.toLowerCase() === criterion.toLowerCase())
            .map(workout => workout.toString())
    }

// 5) Delete a selected part

    deleteWorkout(workoutDate) {
        // Ensure workoutDate is a Date object
        if (!(workoutDate instanceof Date && !isNaN(workoutDate))) {
            throw new Error('Invalid date for deletion')
        }
        this.allMyWorkouts = this.allMyWorkouts.filter(workout => workout.date.getTime() !== workoutDate.getTime())
        this.workoutCount = this.allMyWorkouts.length
    }


// 6) Save all parts to LocalStorage

async saveWorkouts() {
    const workoutsData = this.allMyWorkouts.map(workout => {
        let dateString;
        if (workout.date instanceof Date) {
            dateString = workout.date.toISOString().split('T')[0]; // Convert the Date object to a string in the 'yyyy-mm-dd' format
        } else {
            dateString = workout.date; // If it's not a Date object, assume it's already a string
        }
        return {
            date: dateString,
            type: workout.type,
            duration: workout.duration,
            averageHeartRate: workout.averageHeartRate
        };
    });

    // Save to LocalStorage
    localStorage.setItem('workouts', JSON.stringify(workoutsData));
}

// 7) Load all parts from LocalStorage

loadWorkouts() {
    const workoutsDataString = localStorage.getItem('workouts')
    if (workoutsDataString) {
        const workoutsData = JSON.parse(workoutsDataString)
        return workoutsData.map(workoutData => {
            // Parse the date string into a Date object
            const date = new Date(workoutData.date)
            console.log('Loaded date string:', workoutData.date)
            console.log('Converted Date object:', date)
            // Create a new Workout instance
            return new Workout(
                date,
                workoutData.type,
                workoutData.duration,
                workoutData.averageHeartRate
            )
        })
    }
    return null
}


// 8) Update/edit a part

    updateWorkout(oldDate, oldType, updatedValues) {
        // Validate inputs before updating
        if (!(oldDate instanceof Date && !isNaN(oldDate))) {
            throw new Error('Invalid date for update')
        }
        if (typeof oldType !== 'string') {
            throw new Error('Invalid type for update')
        }
        if (typeof updatedValues !== 'object') {
            throw new Error('Invalid updated values')
        }
        const index = this.allMyWorkouts.findIndex(workout => 
            workout.date.getTime() === new Date(oldDate).getTime() && workout.type === oldType
          );

        if (index !== -1) {
            // Update only the properties that have changed
            Object.keys(updatedValues).forEach(key => {
                if (key in this.allMyWorkouts[index]) {
                    this.allMyWorkouts[index][key] = updatedValues[key]
                } else {
                    throw new Error(`Invalid property: ${key}`)
                }
            })
        } else {
            throw new Error('Workout not found for update')
        }
    }

// 9) Discard /revert edits to a part

    discardChanges() {
        if (this.originalState) {
            this.allMyWorkouts = this.#deepCopyWorkouts(this.originalState)
            this.workoutCount = this.allMyWorkouts.length
        }
    }
    #deepCopyWorkouts(workouts) {
        return workouts.map(workout => new Workout(
            new Date(workout.date.toISOString().split('T')[0]),
            workout.type,
            workout.duration,
            workout.averageHeartRate
        ))
    }
    
    saveState() {
        this.originalState = this.#deepCopyWorkouts(this.allMyWorkouts)
    }


// 12) A calculation across many parts (1)

    calculateTotalCaloriesBurned() {
        return this.allMyWorkouts.reduce((totalCalories, workout) => {
            return totalCalories + workout.calculateCaloriesBurned()
        }, 0) // Start with a total of 0
    }

// 12) A calculation across many parts (2)

    calculateTotalsByType(workoutType) {
        const filteredWorkouts = this.allMyWorkouts.filter(workout => workout.type === workoutType)
        const totals = filteredWorkouts.reduce((acc, workout) => {
            acc.totalDuration += workout.duration
            acc.totalHeartRate += workout.averageHeartRate
            return acc
        }, { totalDuration: 0, totalHeartRate: 0 })

        const averageHeartRate = totals.totalHeartRate / filteredWorkouts.length || 0
        return {
            totalDuration: totals.totalDuration,
            averageHeartRate: averageHeartRate.toFixed(2)
        }
    }

// 14) Get all parts

    getAllWorkouts() {
        return this.allMyWorkouts.map(workout => workout.toString())
    }

// 15) Appropriate database (e.g., IndexedDB, SQLite and MySQL) connectivity

        // DB setup
        async setup() {
        this.db = await openDB('MyWorkoutsDatabase', 1, {
          upgrade(db) {
            if (!db.objectStoreNames.contains('workouts')) {
              db.createObjectStore('workouts', { keyPath: 'id', autoIncrement: true })
            }
          },
        })
      }
    
// Adding data
async addData(workout) {
    const tx = this.db.transaction('workouts', 'readwrite');
    const store = tx.objectStore('workouts');
    
    await store.add(workout);
    await tx.done;
  }
  
  
    // Deleting data
    async deleteData(workoutId) {
        if (!this.db) {
          await this.setup()
        }
        const tx = this.db.transaction('workouts', 'readwrite')
        const store = tx.objectStore('workouts')
        await store.delete(workoutId)
        await tx.done
      }
      
      // Reading data
    async readData(workoutId) {
        if (!this.db) {
            await this.setup()
        }
        const tx = this.db.transaction('workouts', 'readonly')
        const store = tx.objectStore('workouts')
        const workout = await store.get(workoutId)
        await tx.done
        return workout
    }

// Updating data
async updateData(workoutId, updatedWorkout) {
    if (!this.db) {
      await this.setup()
    }
    const tx = this.db.transaction('workouts', 'readwrite')
    const store = tx.objectStore('workouts')
    const currentWorkout = await store.get(workoutId)
    if (currentWorkout) {
      // Update the workout with new data
      const updatedWorkoutData = { ...currentWorkout, ...updatedWorkout };
      await store.put(updatedWorkoutData);
    }
    await tx.done
  }
    
// Clear all data
async clearData() {
    const tx = this.db.transaction('workouts', 'readwrite');
    const store = tx.objectStore('workouts');
    
    await store.clear();
    await tx.done;
  }
  
    
        // Saving array data to IndexedDB
    async saveWorkoutsToDatabase() {
        const workoutsData = this.allMyWorkouts.map(workout => ({
            date: workout.date,
            type: workout.type,
            duration: workout.duration,
            averageHeartRate: workout.averageHeartRate
        }))
        
        await this.setup() // Ensure the IndexedDB is set up
        for (const workout of workoutsData) {
         await this.addData(workout) // Add each workout to IndexedDB
        }
    }

    async loadWorkoutsFromDatabase() {
        // Ensure the IndexedDB is set up
        await this.setup();
        
        // Open a transaction on the 'workouts' object store
        const tx = this.db.transaction('workouts', 'readonly');
        const store = tx.objectStore('workouts');
        
        // Get all records from the store
        const allWorkouts = await store.getAll();
        
        // Convert the plain objects to Workout instances
        const workoutInstances = allWorkouts.map(workoutData => new Workout(
          workoutData.id,
          new Date(workoutData.date).toISOString().split('T')[0], // Convert the date to 'yyyy-mm-dd' format
          workoutData.type,
          workoutData.duration,
          workoutData.averageHeartRate
        ));
        
        await tx.done;
        
        return workoutInstances;
      }
      
      

    toString() {
        let result
        result = `This program has ${this.workoutCount} workouts. \n`
        this.sortWorkout()

        this.allMyWorkouts.forEach((aWorkout) => {
            result += `\t${aWorkout.toString()}\n`
        })
        
        return result
    }
}


// Validation Code  eg node src/components/program.js//

// // Create a new Program instance
// const myProgram = new Program()

// // Add a workout to the program
// myProgram.addWorkout(new Date('2021-01-01'), 'Run', 60, 150)
// myProgram.addWorkout(new Date('2021-02-01'), 'Swim', 60, 150)

// // Print the program's details
// console.log(myProgram.toString())

// // Update a workout
// myProgram.updateWorkout(new Date('2021-01-01'), 'Run', { duration: 45 })

// console.log('adding workout with some defaults')
// myProgram.addWorkout(undefined, 'Run', undefined, 130)

// // Print the updated program's details
// console.log(myProgram.toString())

// console.log("getting all workouts")
// console.log(myProgram.getAllWorkouts())

// console.log("filtering for swim workouts")
// console.log(myProgram.filterWorkouts("Swim"))

// const runTotals = myProgram.calculateTotalsByType('Run')
// console.log(`Total Duration: ${runTotals.totalDuration} minutes`)
// console.log(`Average Heart Rate: ${runTotals.averageHeartRate} BPM`)

