export class Workout {
    date
    type
    duration
    averageHeartRate


constructor(newDate = new Date(), newType = 'Run', newDuration = 30, newAverageHeartRate = 120) {


    this.date = new Date(newDate);
    this.type = newType;
    this.duration = newDuration;
    this.averageHeartRate = newAverageHeartRate;
    this.caloriesBurnedPerMinute = 10; // Example fixed rate

}


    setDate(newDate) {
        if (newDate instanceof Date && !isNaN(newDate)) {
            this.date = newDate
        } else {
            throw new Error('Invalid date')
        }
    }

    setType(newType) {
        const validTypes = ['Run', 'Swim', 'Bike']
        if (validTypes.includes(newType)) {
            this.type = newType
        } else {
            throw new Error('Invalid workout type')
        }
    }

    setDuration(newDuration) {
        if (typeof newDuration === 'number' && newDuration > 0) {
            this.duration = newDuration
        } else {
            throw new Error('Invalid duration')
        }
    }

    setAverageHeartRate(newAverageHeartRate) {
        if (typeof newAverageHeartRate === 'number' && newAverageHeartRate > 0) {
            this.averageHeartRate = newAverageHeartRate
        } else {
            throw new Error('Invalid average heart rate')
        }
    }
    
    toString() {
        const caloriesBurned = this.calculateCaloriesBurned()
        return `${this.date.toISOString()} ${this.type} Workout - Duration: ${this.duration} minutes, Calories burned: ${caloriesBurned} cal, Average Heart Rate: ${this.averageHeartRate} BPM`
    
    }

    calculateCaloriesBurned() {
        return this.duration * this.caloriesBurnedPerMinute;
    }

}