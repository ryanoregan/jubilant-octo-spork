import React, { useState, useEffect } from 'react';
import './App.css'
import { Program } from '../models/program';


// Initialize a new Program instance
const program = new Program();

function AddWorkoutForm({ onAddWorkout, isUpdate, updatingWorkout, setUpdatingWorkout }){
  const getDefaultWorkout = () => ({
    date: new Date(), // Default date is today
    type: 'Run', // Default type
    duration: '30', // Default duration
    averageHeartRate: '120' // Default average heart rate
  });


  const [newWorkout, setNewWorkout] = useState(updatingWorkout || getDefaultWorkout());

  useEffect(() => {
    if (updatingWorkout) {
      setNewWorkout({
        ...updatingWorkout,
        date: new Date(updatingWorkout.date)
      });
    } else {
      setNewWorkout(getDefaultWorkout());
    }
  }, [updatingWorkout]);


  const dateValue = newWorkout.date instanceof Date ? newWorkout.date.toISOString().split('T')[0] : newWorkout.date;

  const handleChange = (event) => {
    setNewWorkout({
      ...newWorkout,
      [event.target.name]: event.target.value
    });
  };


const handleSubmit = (event) => {
  event.preventDefault();

  // Form validation
  if (!newWorkout.date) {
    alert('Please enter a date.');
    return;
  }
  if (!newWorkout.type) {
    alert('Please select a workout type.');
    return;
  }
  if (!newWorkout.duration || isNaN(newWorkout.duration) || newWorkout.duration <= 0) {
    alert('Please enter a valid duration.');
    return;
  }
  if (!newWorkout.averageHeartRate || isNaN(newWorkout.averageHeartRate) || newWorkout.averageHeartRate <= 0) {
    alert('Please enter a valid average heart rate.');
    return;
  }

  // Parse the duration and average heart rate as numbers
  const workoutWithParsedValues = {
    ...newWorkout,
    date: new Date(newWorkout.date),
    duration: parseInt(newWorkout.duration, 10),
    averageHeartRate: parseInt(newWorkout.averageHeartRate, 10)
  };
  onAddWorkout(workoutWithParsedValues);        
  setNewWorkout(getDefaultWorkout()); // Reset the form to the default values
};

return (
<form onSubmit={handleSubmit}>
  <div className="form-labels">
    <label>Date</label>
    <label>Type</label>
    <label>Duration</label>
    <label>Average Heart Rate</label>
  </div>
  <div className="form-inputs">
    <input className="form-input" type="date" name="date" value={dateValue} onChange={handleChange} />
    <select className="form-input" name="type" value={newWorkout.type} onChange={handleChange}>
      <option value="Run">Run</option>
      <option value="Bike">Bike</option>
      <option value="Swim">Swim</option>
    </select>
    <input className="form-input" name="duration" value={newWorkout.duration} onChange={handleChange} placeholder="Duration" />
    <input className="form-input" name="averageHeartRate" value={newWorkout.averageHeartRate} onChange={handleChange} placeholder="Average Heart Rate" />
  </div>
  <button type="submit">{isUpdate ? 'Update Workout' : 'Add Workout'}</button>
  {isUpdate && <button type="button" onClick={() => setUpdatingWorkout(null)}>Cancel</button>}
</form>

);
}



function WorkoutList({ workouts, onDeleteWorkout, onUpdateWorkout, updatingWorkout, setUpdatingWorkout, storageType })  {
  // Render the list of workouts
  return (
    <ul>
      {workouts.map((workout, index) => {
        // Calculate calories burned for this workout
        const caloriesBurned = workout.duration * 10;

        return (
          <li key={index}>
            {workout.date.toLocaleString().split('T')[0]} - {workout.type} - {workout.duration} minutes - {workout.averageHeartRate} BPM - Calories Burned: {caloriesBurned}
            {storageType === 'localStorage' ? (
              <button className='delete-button' onClick={() => onDeleteWorkout(workout.date)}>Delete</button>
            ) : storageType === 'indexedDB' ? (
              <button onClick={() => onDeleteWorkout(workout.id)}>Delete</button>
            ) : null}

            <button onClick={() => setUpdatingWorkout(workout)}>Edit</button>
            {updatingWorkout === workout && (
              <>
                <AddWorkoutForm onAddWorkout={onUpdateWorkout} isUpdate={true} updatingWorkout={updatingWorkout} setUpdatingWorkout={setUpdatingWorkout} />
              </>
            )}
          </li>
        );
      })}
    </ul>
  );
}




function App() {
    const [workouts, setWorkouts] = useState([]);
    const [filter, setFilter] = useState('');
    const [sort, setSort] = useState('date'); // Default sort is by date
    const [updatingWorkout, setUpdatingWorkout] = useState(null);
    const [storageType, setStorageType] = useState(null);

    const handleSaveFile = async () => {
      // Check for support
      if ('showSaveFilePicker' in window) {
        // Generate a string representation of the current date and time
        const now = new Date();
        const dateTimeString = now.toISOString().replace(/[:.]/g, '-');
  
        // Create an options object
        const options = {
          suggestedName: `workout-data-${dateTimeString}.txt`,
          types: [
            {
              description: 'Text Files',
              accept: {
                'text/plain': ['.txt', '.text'],
              },
            },
          ],
        };
  
        // Show the file picker and get a handle on the file
        const fileHandle = await window.showSaveFilePicker(options);
  
        // Create a writable stream
        const writableStream = await fileHandle.createWritable();
  
        // Write the current workout data to the file
        const workoutData = JSON.stringify(workouts);
        await writableStream.write(workoutData);
  
        // Close the stream
        await writableStream.close();
  
        console.log('File saved successfully.');
      } else {
        console.log('File System Access API not supported.');
      }
    };
    
    const handleLoadFile = async () => {
      // Check for support
      if ('showOpenFilePicker' in window) {
        // Create an options object
        const options = {
          types: [
            {
              description: 'Text Files',
              accept: {
                'text/plain': ['.txt', '.text'],
              },
            },
          ],
        };
    
        // Show the file picker and get a handle on the file
        const [fileHandle] = await window.showOpenFilePicker(options);
    
        // Create a file object
        const file = await fileHandle.getFile();
    
        // Read the contents of the file
        const contents = await file.text();
    
        // Now you can use the contents of the file
        // For example, if the file contains JSON data, you can parse it
        const data = JSON.parse(contents);
    
        // And then you can set your state with this data
        setWorkouts(data);
    
        // Save the data to Local Storage
        localStorage.setItem('workouts', JSON.stringify(data));
      } else {
        console.log('File System Access API not supported.');
      }
    };
    

     // Use an effect to log the workouts state whenever it changes
  useEffect(() => {
    console.log(workouts);
  }, [workouts]);
    

    const handleUseLocalStorage = () => {
      setStorageType('localStorage');
    };
  
    const handleUseIndexedDB = () => {
      setStorageType('indexedDB');
    };

    const handleBack = () => {
      setStorageType(null); // Reset the storage type
    };
  
    // Load workouts from localStorage when the component mounts

    useEffect(() => {
      const loadWorkouts = async () => {
        if (storageType === 'localStorage') {
          const loadedWorkouts = program.loadWorkouts();
          if (loadedWorkouts) {
            setWorkouts(loadedWorkouts);
          }
        } else if (storageType === 'indexedDB') {
          const loadedWorkouts = await program.loadWorkoutsFromDatabase();
          if (loadedWorkouts) {
            setWorkouts(loadedWorkouts);
          }
        }
      };
    
    

      loadWorkouts();
    }, [storageType]); // Add storageType as a dependency
    
    
    useEffect(() => {
      // Update the badge
      if (navigator.setAppBadge) {
        navigator.setAppBadge(workouts.length);
      }
    }, [workouts]); // Only re-run the effect when workouts changes

    const handleAddWorkout = async (newWorkout) => {
      if (storageType === 'localStorage') {
        // Convert the date to a string in the format 'yyyy-mm-dd'
        const dateOnly = new Date(newWorkout.date).toISOString().split('T')[0];
      
        // Use the dateOnly string instead of the Date object
        program.addWorkout(dateOnly, newWorkout.type, newWorkout.duration, newWorkout.averageHeartRate);
        
        // Also update the newWorkout object before adding it to the state
        newWorkout.date = dateOnly;
        setWorkouts([...workouts, newWorkout]);
        
        program.saveWorkouts();
      } else if (storageType === 'indexedDB') {
        // Generate a unique ID
        const newId = Date.now();
    
        // Convert the date to a string in the format 'yyyy-mm-dd'
        const dateOnly = new Date(newWorkout.date).toISOString().split('T')[0];
    
        // Use the dateOnly string instead of the Date object
        program.addWorkout(dateOnly, newWorkout.type, newWorkout.duration, newWorkout.averageHeartRate);
        
        // Also update the newWorkout object before adding it to the state
        newWorkout.date = dateOnly;
        newWorkout.id = newId; // Add the ID to the newWorkout object
        setWorkouts([...workouts, newWorkout]);
        
        await program.setup();
        await program.addData(newWorkout);
      }
    };
    

    const handleDeleteWorkout = async (workoutId) => {
      if (storageType === 'localStorage') {
        console.log(workoutId)
        const dateToDelete = new Date(workoutId);
        const workoutExists = workouts.some(workout => workout.date === workoutId);
        if (workoutExists) {
          program.deleteWorkout(dateToDelete);
          setWorkouts(workouts.filter(workout => workout.date !== workoutId));
          program.saveWorkouts();
          alert('Workout deleted successfully!');
        } else {
          alert('Workout not found!');
        }
      } else if (storageType === 'indexedDB') {
        const workoutExists = workouts.some(workout => workout.id === workoutId);
        if (workoutExists) {
          setWorkouts(workouts.filter(workout => workout.id !== workoutId));
          console.log(workoutId)
          await program.deleteData(workoutId);
          alert('Workout deleted successfully!');
        } else {
          alert('Workout not found!');
        }
      }
    };
    
    
    const handleUpdateWorkout = async (newWorkout) => {
      if (storageType === 'localStorage') {
        const dateOnly = new Date(newWorkout.date).toISOString().split('T')[0];
        try {
          handleSaveState(); // Save state before updating the workout
          program.updateWorkout(new Date(updatingWorkout.date), updatingWorkout.type, newWorkout);
          const updatedWorkouts = workouts.map(workout => 
              (workout.date === updatingWorkout.date && workout.type === updatingWorkout.type) ? { ...workout, ...newWorkout } : workout
          );
          setWorkouts(updatedWorkouts);
          const updatedWorkout = updatedWorkouts.find(workout => workout.date === updatingWorkout.date && workout.type === updatingWorkout.type);
          setUpdatingWorkout(updatedWorkout); // Update the updatingWorkout state
          program.saveWorkouts();
          alert('Workout updated successfully!');
        } catch (error) {
          alert(error.message);
        }
      } else if (storageType === 'indexedDB') {
        const dateOnly = new Date(newWorkout.date).toISOString().split('T')[0];
        try {
          handleSaveState(); // Save state before updating the workout
          program.updateWorkout(new Date(updatingWorkout.date), updatingWorkout.type, newWorkout);
          const updatedWorkouts = workouts.map(workout => 
              (workout.date === updatingWorkout.date && workout.type === updatingWorkout.type) ? { ...workout, ...newWorkout } : workout
          );
          setWorkouts(updatedWorkouts);
          const updatedWorkout = updatedWorkouts.find(workout => workout.date === updatingWorkout.date && workout.type === updatingWorkout.type);
          setUpdatingWorkout(updatedWorkout); // Update the updatingWorkout state
          program.saveWorkouts();
          alert('Workout updated successfully!');
        } catch (error) {
          alert(error.message);
        }
        await program.updateData(updatingWorkout.id, newWorkout);
      }
    };
    


    const handleDiscardChanges = async () => {
      if (storageType === 'localStorage') {
        try {
          program.discardChanges();
          // Remove the time from the date for each workout
          const workoutsWithoutTime = program.allMyWorkouts.map(workout => ({
            ...workout,
            date: workout.date.toISOString().split('T')[0]
          }));
          setWorkouts(workoutsWithoutTime);
          program.saveWorkouts(); // Update the changes in localStorage
          alert('Changes discarded successfully!');
          handleSaveState(); // Save state after discarding the changes
        } catch (error) {
          alert(error.message);
        }
      } else if (storageType === 'indexedDB') {
        try {
          program.discardChanges();
          // Remove the time from the date for each workout
          const workoutsWithoutTime = program.allMyWorkouts.map(workout => ({
            ...workout,
            date: workout.date.toISOString().split('T')[0]
          }));
          setWorkouts(workoutsWithoutTime);
      
          // Clear all data from the IndexedDB database
          await program.clearData();
      
          // Save the current state back to the IndexedDB database
          await program.saveWorkoutsToDatabase();
      
          alert('Changes discarded successfully!');
          handleSaveState(); // Save state after discarding the changes
        } catch (error) {
          alert(error.message);
        }
      }
    };
    
    const handleSaveState = () => {
      try {
        program.saveState();
        // alert('State saved successfully!'); // Commented out
      } catch (error) {
        // alert(error.message); // Commented out
        console.error(error.message); // Log the error message to the console instead
      }
    };

const handleFilterChange = (event) => {
  setFilter(event.target.value);
};

const handleSortChange = (event) => {
  setSort(event.target.value);
};

const filteredWorkouts = filter ? workouts.filter(workout => workout.type === filter) : workouts;

const sortedWorkouts = [...filteredWorkouts].sort((a, b) => {
  if (sort === 'date') {
    return new Date(a.date) - new Date(b.date);
  } else if (sort === 'duration') {
    return a.duration - b.duration;
  }
});



    // Render the application
    return (
      <div>
        <img className='logo' src="../icon.png" alt="Logo" />
        <h1 className='title'>Workout Program</h1>
        {storageType === null ? (
          <div className="button-container">
            <button onClick={handleUseLocalStorage}>Use Local Storage</button>
            <button onClick={handleUseIndexedDB}>Use IndexedDB</button>
            <button onClick={handleSaveFile}>Save to File</button>
            <button onClick={handleLoadFile}>Load from File</button>
          </div>
        ) : (
          <>
            <AddWorkoutForm onAddWorkout={handleAddWorkout} />
            <h2>Your Workouts</h2>
            <select value={filter} onChange={handleFilterChange}>
              <option value="">All</option>
              <option value="Run">Run</option>
              <option value="Bike">Bike</option>
              <option value="Swim">Swim</option>
            </select>
            <select value={sort} onChange={handleSortChange}>
              <option value="date">Sort by Date</option>
              <option value="duration">Sort by Duration</option>
            </select>
            <WorkoutList workouts={sortedWorkouts} onDeleteWorkout={handleDeleteWorkout} onUpdateWorkout={handleUpdateWorkout} updatingWorkout={updatingWorkout} setUpdatingWorkout={setUpdatingWorkout} storageType={storageType} />
            <button className='back-button' onClick={handleBack}>Back</button>
            <button onClick={handleDiscardChanges}>Revert Last Edit</button>
            <p>Total Calories Burned: {program.calculateTotalCaloriesBurned()}</p>
          </>
        )}
      </div>
    );
  }
  
export default App;











